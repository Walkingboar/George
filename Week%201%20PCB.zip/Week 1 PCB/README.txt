Week 1 PCB - 4-key macro pad starter layout.
Layout: 1.9in ST7789 top-left, EC11 beside it, 4 keys in one row.
IMPORTANT: footprints are starter/custom approximations; verify exact module dimensions and pin spacing before manufacturing.
